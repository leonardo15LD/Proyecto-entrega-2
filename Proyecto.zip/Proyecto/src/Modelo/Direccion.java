package Modelo;

import java.util.ArrayList;
import java.util.Scanner;

public class Direccion {

    Scanner leer = new Scanner(System.in);
    private int noVivienda;
    private String localidad, ciudad, departamento, pais, caracteristicas;

    public Direccion() {
    }
    private Direccion detec[] = new Direccion[40];//relacion de agregacion
    ArrayList<Direccion> listaDireccion = new ArrayList();

    public Direccion(int noVivienda, String localidad, String ciudad, String departamento, String pais, String caracteristicas) {
        this.noVivienda = noVivienda;
        this.localidad = localidad;
        this.ciudad = ciudad;
        this.departamento = departamento;
        this.pais = pais;
        this.caracteristicas = caracteristicas;
    }

    public int getNoVivienda() {
        return noVivienda;
    }

    public void setNoVivienda(int noVivienda) {
        this.noVivienda = noVivienda;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getCaracteristicas() {
        return caracteristicas;
    }

    public void setCaracteristicas(String caracteristicas) {
        this.caracteristicas = caracteristicas;
    }

    public void pedirDatos() {
        System.out.println("cuantas direcciones desea registar (segun la cantididad de casos que registro): ");
        int numDirec = leer.nextInt();
        for (int i = 0; i < numDirec; i++)
        {
            System.out.println("escriba el numero de vivienda: ");
            noVivienda = leer.nextInt();
            System.out.println("escriba la localidad: ");
            localidad = leer.next();
            System.out.println("escriba la ciudad: ");
            ciudad = leer.next();
            System.out.println("escriba el departamento: ");
            departamento = leer.next();
            System.out.println("escriba el pais: ");
            pais = leer.next();
            detec[i] = new Direccion(noVivienda, localidad, ciudad, departamento, pais, caracteristicas);
            listaDireccion.add(detec[i]);
        }

    }

    public void imprimir() {
        listaDireccion.forEach((Direccion direccion1) ->
        {
            mostrar(direccion1);
            System.out.println("------------------------------------");
        });
    }

    public void mostrar(Direccion direccion) {
        System.out.println("numero de vivienda: " + getNoVivienda() + "\nlocalidad: " + getLocalidad() + "\nciudad: " + getCiudad()
                + "\ndepartamento: " + getDepartamento() + "\npais: " + getPais());
    }

}
