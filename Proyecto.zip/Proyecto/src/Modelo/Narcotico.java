package Modelo;
import java.util.Scanner;
public class Narcotico {

    String tipoNarcotico;
    Detective dectective;
    Scanner leer = new Scanner(System.in);

    public String getTipoNarcotico() {
        return tipoNarcotico;
    }

    public void setTipoNarcotico(String tipoNarcotico) {
        this.tipoNarcotico = tipoNarcotico;
    }

    public Detective getDectective() {
        return dectective;
    }

    public void setDectective(Detective dectective) {
        this.dectective = dectective;
    }

    public Narcotico() {
    }

    public Narcotico(String tipoNarcotico, Detective dectective) {
        this.tipoNarcotico = tipoNarcotico;
        this.dectective = dectective;
    }

    public void pedirDatos() {
        System.out.println("que tipo de caso es: (local,estatal o federal)");
        tipoNarcotico = leer.next();
    }

    public void mostrar() {
        System.out.println("tipo de caso: " + getTipoNarcotico());
    }

}
