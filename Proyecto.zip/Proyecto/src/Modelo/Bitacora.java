package Modelo;

import java.util.ArrayList;
import java.util.Scanner;

public class Bitacora {

    Caso caso;
    ArrayList<Anotaciones> listaAnota = new ArrayList();
    Oficina ofi = new Oficina();
    private final Anotaciones anotacioneseslis[] = new Anotaciones[40];
    Scanner leer = new Scanner(System.in);

    public void pedirAnota() {
        System.out.println("escriba cuantas anotaciones desea registrar: ");
        int numNota = leer.nextInt();

        for (int i = 0; i < numNota; i++)
        {
            System.out.println("----------ANOTACIONES-----------");
            System.out.println("escriba la fecha: ");
            String fecha = leer.next();
            System.out.println("escriba la observacion: ");
            String observaciones = leer.next();
            anotacioneseslis[i] = new Anotaciones(fecha, observaciones);
            listaAnota.add(anotacioneseslis[i]);

        }

    }

    public void imprimir() {
        listaAnota.forEach((Anotaciones ano) ->
        {
            mostrarAnota(ano);
            System.out.println("------------------------------------");
        });
    }

    public void mostrarAnota(Anotaciones a) {
        System.out.println("----------ANOTACIONES REGISTRADAS-----------");
        System.out.println("fecha: " + a.getFecha() + "\nobservacion: " + a.getObservaciones());
    }

}
