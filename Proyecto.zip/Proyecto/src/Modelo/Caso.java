package Modelo;

public class Caso extends Oficina {

    private int numero, numCasos, tipo;
   
    private String descripcion, codigo, nombreClave;

    private Detective detectives;//relacion de agregacion
    

    public Caso() {
    }

    public Caso(int numero, String descripcion, String codigo, String nombreClave) {
        this.numero = numero;
        this.descripcion = descripcion;
        this.codigo = codigo;
        this.nombreClave = nombreClave;
    }

    @Override
    public int getTipo() {
        return tipo;
    }

    @Override
    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    @Override
    public int getNumCasos() {
        return numCasos;
    }

    @Override
    public void setNumCasos(int numCasos) {
        this.numCasos = numCasos;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombreClave() {
        return nombreClave;
    }

    public void setNombreClave(String nombreClave) {
        this.nombreClave = nombreClave;
    }

    public Detective getDetectives() {
        return detectives;
    }

    public void setDetectives(Detective detectives) {
        this.detectives = detectives;
    }

    

}
