package Modelo;
import java.util.Scanner;
public class Cibercrimen {

    String ciberAso;
    Detective dectective;
    Scanner leer = new Scanner(System.in);
    public Cibercrimen() {
    }

    public String getCiberAso() {
        return ciberAso;
    }

    public void setCiberAso(String ciberAso) {
        this.ciberAso = ciberAso;
    }

    public Detective getDectective() {
        return dectective;
    }

    public void setDectective(Detective dectective) {
        this.dectective = dectective;
    }

    public Cibercrimen(String ciberAso, Detective dectective) {
        this.ciberAso = ciberAso;
        this.dectective = dectective;
    }

    public void pedirDatos() {
        System.out.println("especifique el tipo de cibercrimen: (robo de identidad, robo de información, fraudes por internet,etc");
        ciberAso = leer.next();
    }

    public void mostrar() {
        System.out.println("asociacion del crimen: "+getCiberAso());
    }

}
