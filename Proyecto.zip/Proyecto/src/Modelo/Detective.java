package Modelo;

import java.util.ArrayList;
import java.util.Scanner;

public class Detective {

    private int identificacion;
    private String nombres, apellidos, años;
    private String tipoCaso;

    private Detective detec[] = new Detective[40];//relacion de agregacion
    ArrayList<Detective> listaDetectives = new ArrayList();
    Scanner leer = new Scanner(System.in);

    public Detective() {
    }

    public Detective(int identificacion, String nombres, String apellidos, String años, String tipoCaso) {
        this.identificacion = identificacion;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.años = años;
        this.tipoCaso = tipoCaso;
    }

    public int getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(int identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getAños() {
        return años;
    }

    public void setAñosExpe(String añosExpe) {
        this.años = añosExpe;
    }

    public String getTipoCaso() {
        return tipoCaso;
    }

    public void setTipoCaso(String tipoCaso) {
        this.tipoCaso = tipoCaso;
    }

    public void pedirDatosdetec() {

        System.out.println("cuantos detectives desea registrar: ");
        int numDect = leer.nextInt();
        for (int i = 0; i < numDect; i++)
        {
            System.out.println("DETECTIVE " + (i + 1));
            System.out.println("escriba la identificacion del detective");
            identificacion = leer.nextInt();
            System.out.println("escriba el nombre del detectve: ");
            nombres = leer.next();
            System.out.println("escriba el apellido del detective: ");
            apellidos = leer.next();
            System.out.println("escriba los años de experiencia: ");
            años = leer.next();
            detec[i] = new Detective(identificacion, nombres, apellidos, años, tipoCaso);
            listaDetectives.add(detec[i]);
        }

    }

    public void imprimir() {
        listaDetectives.forEach((Detective Dec) ->
        {
            mostrar(Dec);
            System.out.println("------------------------------------");
        });
    }

    public void mostrar(Detective dec) {
        System.out.println("-----------DECTECTIVES REGISTRADOS-----------");
        System.out.println("identificacion: " + identificacion + "\nnombres: " + nombres
                + "\napellidos: " + apellidos + "\naños de experiencia: " + años);
    }

}
