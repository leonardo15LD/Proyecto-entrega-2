package Modelo;

import java.util.ArrayList;
import java.util.Scanner;

public class Oficina  {

    private int tipo, numCasos;
    Scanner leer = new Scanner(System.in);
    ArrayList<Caso> listaCasos = new ArrayList();

    public int getNumCasos() {
        return numCasos;
    }

    public void setNumCasos(int numCasos) {
        this.numCasos = numCasos;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }
    private final Caso ca[] = new Caso[40];

    public void pedirDatos() {
        System.out.println("-------ABRIR CASO--------");
        System.out.println("cuantos casos desea abrir: ");
        numCasos = leer.nextInt();
        for (int i = 0; i < numCasos; i++)
        {
            System.out.println("-----------CASO " + (i + 1) + "------------");
            System.out.println("asigne un numero al caso: ");
            int numero = leer.nextInt();
            System.out.println("escriba una descripcion del caso: ");
            String descripcion = leer.next();
            System.out.println("escriba un codigo de prioridad (A=poca importancia, B=moderada, C=relevante): ");
            String codigo = leer.next();
            System.out.println("escriba el nombre en clave del caso: ");
            String nombreClave = leer.next();
            ca[i] = new Caso(numero, descripcion, codigo, nombreClave);
            listaCasos.add(ca[i]);
            System.out.println("1.Cibercrimen \n2.Homicidio \n3.Narcoticos");
            System.out.println("a que tipo de caso pertenece: ");
            tipo = leer.nextInt();
            setTipo(tipo);

        }
    }
    Cibercrimen ciber;
    Homicidio homi;
    Narcotico narco;
    public void imprimirtipo() {
        switch (tipo)
        {
            case 1:
            {
                
                ciber.pedirDatos();
                
                break;
            }
            case 2:
            {
                System.out.println("SEGUNDO DETECTIVE ASIGNADO(ingrese sus datos mas adelante)");
                break;
            }
            case 3:
            {
               
                narco.pedirDatos();
                
                break;
            }

        }
    }

    public void imprimir() {
        listaCasos.forEach(f ->
        {
            mostrar(f);
            System.out.println("------------------------------------");
        });
    }

    public void mostrar(Caso casox) {
        System.out.println("--------CASOS REGISTRADOS-----------");
        System.out.println("numero del caso: " + casox.getNumero() + "\ndescripcion: " + casox.getDescripcion() + "\ncodigo de prioridad: " + casox.getCodigo()
                + "\nnombre en clave: " + casox.getNombreClave());

    }

    public void eliminar() {
        int indice;
        System.out.println("cuantos casos desea eliminar: ");
        int casoEliminar = leer.nextInt();
        for (int i = 0; i < casoEliminar; i++)
        {
            System.out.println("escriba el numero del caso a eliminar: ");
            ca[i].setNumero(leer.nextInt());
            indice = listaCasos.indexOf(ca[i]);
            if (indice != -1)
            {
                listaCasos.remove(indice);
                System.out.println("CASO ELIMINADO CORRECTAMENTE");
            } else
            {
                System.out.println("CASO NO ENCONTRADO");
            }
        }

    }

}
