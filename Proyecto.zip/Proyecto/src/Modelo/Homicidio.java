package Modelo;

public class Homicidio extends Caso {

    String ciberAso;
    Detective dectective[] = new Detective[2];

    public String getCiberAso() {
        return ciberAso;
    }

    public void setCiberAso(String ciberAso) {
        this.ciberAso = ciberAso;
    }

    public Detective[] getDectective() {
        return dectective;
    }

    public void setDectective(Detective[] dectective) {
        this.dectective = dectective;
    }

    public Homicidio() {
    }

}
