package Modelo;

import java.util.ArrayList;
import java.util.Scanner;

public class Sospechoso {

    private int id, edad, noVivienda;
    private String nombre, apellido, alias;
    private Caso casos[];//relacion de agregacion

    Scanner leer = new Scanner(System.in);

    ArrayList<Sospechoso> listasospe = new ArrayList();
    private final Sospechoso sospe[] = new Sospechoso[40];

    public Sospechoso(int id, int edad, String nombre, String apellido, String alias) {
        this.id = id;
        this.edad = edad;
        this.nombre = nombre;
        this.apellido = apellido;
        this.alias = alias;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getNoVivienda() {
        return noVivienda;
    }

    public void setNoVivienda(int noVivienda) {
        this.noVivienda = noVivienda;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public Caso[] getCasos() {
        return casos;
    }

    public void setCasos(Caso[] casos) {
        this.casos = casos;
    }

    public Sospechoso() {
    }

    public void pedirDatos() {
        System.out.println("cuantos sospechos estan vinculados al caso: ");
        int sospevin = leer.nextInt();
        for (int i = 0; i < sospevin; i++)
        {
            System.out.println("SOSPECHOSO " + (i + 1));
            System.out.println("identificacion sospechoso: ");
            id = leer.nextInt();
            System.out.println("escriba la edad del sospechoso: ");
            edad=leer.nextInt();
            System.out.println("nombre del sospechoso: ");
            nombre = leer.next();
            System.out.println("apellidos del sospechoso: ");
            apellido = leer.next();
            System.out.println("alias del sospechoso: ");
            alias = leer.next();
            sospe[i] = new Sospechoso(id, edad, nombre, apellido, alias);
            listasospe.add(sospe[i]);
            System.out.println("---------SOSPECHOSO DEL CASO " + (i + 1) + "----------");
        }

    }

    public void imprimir() {
        listasospe.forEach((Sospechoso sospe1) ->
        {
            mostrar(sospe1);
            System.out.println("------------------------------------");
        });
    }

    public void mostrar(Sospechoso sospechoso) {
        System.out.println("--------------SOSPECHOSOS REGISTRADOS------------");
        System.out.println("id: " + getId() + "\nedad:" + getEdad()
                + "\nnombres: " + getNombre() + "\napellidos: " + getApellido() + "\nalias: " + getAlias());
    }
}
